#!/system/bin/busybox sh

# INSTALAÇÃO INICIAL EXPERIMENTAL DROPBEAR
# Comandos
# backup-debuggerd - ( se debuggerd_ não existir, copia debuggerd para debuggerd_ )

if [ "$1" == "backup-debuggerd" ];then
	if [ ! -f /system/bin/debuggerd_ ];then
		/system/bin/busybox cp /system/bin/debuggerd /system/bin/debuggerd_
		exit 0
	fi
fi
